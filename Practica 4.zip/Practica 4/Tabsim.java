/**
*@author Gilberto Vargas Hernández
*Clase que gestiona las etiquetas y sus valores
*/

import java.io.*;
import java.util.*;
import java.util.regex.*;
public class Tabsim{
	private Map<String,Integer> diccionario;
	public Tabsim(){
		diccionario=new TreeMap<String,Integer>();
	}
	public boolean agregar(String etiqueta, Integer contLoc){
		//System.out.println(etiqueta+" "+contLoc);
		if(diccionario.get(etiqueta)==null){
			diccionario.put(etiqueta,contLoc);
			return true;
		}else{
			return false;
		}
	}
	public void guardar(String dir){
		try{
			BufferedWriter arch=new BufferedWriter(new FileWriter((new File(dir+".Tabsim")).getAbsoluteFile()));
			Iterator i = diccionario.keySet().iterator();
			while(i.hasNext()){
				String et=(String)i.next();
				arch.write(et+"\t\t"+Clasificador.intHexWord(diccionario.get(et))+"\n");
			}
			arch.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}