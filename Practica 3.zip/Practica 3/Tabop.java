/**
*@author Gilberto Vargas Hernández
*Clase que carga el TABOP y organiza la informacion
*/

import java.io.*;
import java.util.*;
import java.util.regex.*;

public class Tabop{
	//Los datos se almacenan enmascarados en un int. Como el tamaño no rebaza los 10 bits, puedo
	//Usar los primero 8 bits para un dato y los otro 8 para el segundo usando un solo int. 
	public Map<String,Map<String,Integer> > codigosMaquina;
	public Map<String, Map<String,Integer> > bits;
	Tabop(String s){
		codigosMaquina = new LinkedHashMap<String, Map<String,Integer> >();
		bits = new LinkedHashMap<String, Map<String,Integer> >();
		BufferedReader tab ;
		try{
			//Se abre un archivo donde esta almacenado el tabop y se lee linea a linea
			tab= new BufferedReader(new InputStreamReader(new FileInputStream(s)));
			String linea;
			while((linea = tab.readLine())!=null){
				//Se obtienen los datos por el delimitador y se extraen los datos. 
				StringTokenizer tok = new StringTokenizer(linea ,"|");
				String instruccion = tok.nextToken();
				String modo = tok.nextToken();
				Integer hex = Integer.parseInt(tok.nextToken(),16);
				Integer calculados = Integer.parseInt(tok.nextToken());
				Integer parametros = Integer.parseInt(tok.nextToken());
				//Si no existe codop aun se agrega un nuevo arbol
				if(!codigosMaquina.containsKey(instruccion)){
					LinkedHashMap<String,Integer> temp= new LinkedHashMap<String,Integer>();
					LinkedHashMap<String,Integer> temp2= new LinkedHashMap<String,Integer>();
					codigosMaquina.put(instruccion, temp);
					bits.put(instruccion, temp2);
				}
				//Se agrega el nuevo modo de direccionamiento
				codigosMaquina.get(instruccion).put(modo,hex);
				//Con las máscaras de bits
				bits.get(instruccion).put(modo,(calculados<<8)+parametros);
			}
			tab.close();
		}catch(Exception e){
			//En caso de que ocurra algun error de ejecucion mostramos el error
			e.printStackTrace();
		}
	}
	/**
	 *Funcion que obtiene los modos de direccionamiento de un codop. Valida el operando, y si hay algun
	 *error lo retorna. 
	 *@param String codop, String op, Un codigo de operacion y un operando validos. 
	 *@return Una cadena con los modos de direccionamiento o un error en su defecto
	 */
	String dameModos(String codop, String op){
		Map<String,Integer> m = codigosMaquina.get(codop);
		if(m!=null){
			String ret="";
			Iterator i = m.keySet().iterator();
			if(m.keySet().size()==1){
				String s = (String)i.next();
				if(op.equals("NULL")){
					return (bits.get(codop).get(s)%256==0?s:"Error: El operando debe ser distinto a NULL");
				}else{
					return (bits.get(codop).get(s)%256!=0?s:"Error: El operando debe ser NULL");
				}
			}else{
				while(i.hasNext()){
					String s = (String)i.next();
					if(op.equals("NULL")){
						ret+= (bits.get(codop).get(s)%256==0?s+",":"");
					}else{
						ret+= (bits.get(codop).get(s)%256!=0?s+",":"");
					}
				}
				if(ret.equals("")){
					ret = "Error: El operando debe ser distinto de NULL";
				}
				return ret.substring(0,ret.length()-1);
			}
		}else{
			return "Error: El codop no existe";
		}
	}

	String dameModo(String codop, String op, String cadenaModos){
		Vector<String> modos = new Vector<String>();
		StringTokenizer tok =new StringTokenizer(cadenaModos,",");
		while(tok.hasMoreTokens())
			modos.add(tok.nextToken());
		if(modos.isEmpty()){
			return "";
		}
		for(int i=0;i<modos.size();i++){
			switch(modos.elementAt(i)){
				case "INH":
					if(Clasificador.modoInherente(op)){
						return "INH";
					}
				case "DIR":
					if(Clasificador.modoDirecto(op)){
						return "DIR";
					}
				case "EXT":
					if(Clasificador.modoExtendido(op)){
						return "EXT";	
					}

				case "IMM8":
					if(Clasificador.modoInmediato8b(op)){
						return "IMM8";
					}
				case "IMM16":
					if(Clasificador.modoInmediato16b(op)){
						return "IMM16";
					}
				case "IDX":
					if(Clasificador.modoIndizado5b(op)||Clasificador.modo_Cremento(op)||Clasificador.modoAcumulador(op)){
						return "IDX";
					}
				case "IDX1":
					if(Clasificador.modoIndizado9b(op)){
						return "IDX1";
					}
				case "IDX2":
					if(Clasificador.modoIndizado16b(op)){
						return "IDX2";
					}
				case "[IDX]":
					if(Clasificador.modoIndirecto16b(op)||Clasificador.modoAcumuladorIndirecto(op)){
						return "[IDX]";
					}
				case "REL8":
					if(Clasificador.modoRelativo8b(op)){
						return "REL8";
					}
				case "REL9":
					if(Clasificador.modoRelativo9b(op)){
						return "REL9";
					}
				case "REL16":
					if(Clasificador.modoRelativo16b(op)){
						return "REL16";
					}

				default:
					//System.out.println(modos.elementAt(i));
			}
		}
		return "Error: "+modoError(op,modos);
	}

	String modoError(String op, Vector<String> modos){
		if(op.charAt(0)=='#'){
			String num = op.substring(1);
			if(num.equals("")){
				return "Se esperaba un dato numerico";
			}
			int x=Clasificador.parseInt(num);
			if(x==(1<<16)+1){
				return "El numero no esta bien Formado";
			}else if(x>=1<<16){
				return "Error de rango";
			}else{
				return "No compatible con modo IMM";
			}
		}else{
			Pattern p = Pattern.compile("\\[[^\\]]*$");
			Matcher m = p.matcher(op);
			if(m.find()){
				//System.out.println("Debug: "+op);
				return "Se esperaba ']' al final del codop";
			}

			p = Pattern.compile("^[^\\[]*\\]");
			m = p.matcher(op);
			if(m.find()){
				//System.out.println("Debug: "+op);
				return "Se esperaba '[' al inicio del codop";
			}

			p = Pattern.compile(".*,.*,.*");
			m = p.matcher(op);
			if(m.find()){
				//System.out.println("Debug: "+op);
				return "Error en la cantidad de argumentos del codop";
			}

			p = Pattern.compile("[+-].*[+-],.*|.*,[+-].*[+-]");
			m = p.matcher(op);
			if(m.find()){
				//System.out.println("Debug: "+op);
				return "No puede haber postincremento y preincremento en una misma instruccion";
			}

			if(op.equals(",")){
				return "No pueden ser vacios los argumentos en el operando";
			}


			p = Pattern.compile("^.*,.*[+-].*$");
			m = p.matcher(op);
			if(m.find()){ //Modo idx
				int idx = op.indexOf(',');
				int x = Clasificador.parseInt(op.substring(0,idx));
				if(x!=(1<<16)+1){
					if(x>=8 || x<=0){
						return "Error de rango";
					}
				}
			}

			p = Pattern.compile("^.*,.*$");
			m = p.matcher(op);
			if(m.find()){ //Modo idx
				int idx = op.indexOf(',');
				int x = Clasificador.parseInt(op.substring(0,idx));
				System.out.println(op.substring(0,idx));
				if(x!=(1<<16)+1){
					if(x>=65536){
						return "Error de rango";
					}
				}
			}

			p = Pattern.compile("^\\[.*,.*\\]$");
			m = p.matcher(op);
			if(m.find()){ //Modo idx
				int idx = op.indexOf(',');
				int x = Clasificador.parseInt(op.substring(1,idx));
				if(x!=(1<<16)+1){
					if(x>=1<<16){
						return "Error de rango";
					}
				}
			}

			int x=Clasificador.parseInt(op);
			if(x!=(1<<16)+1){
				if(x>=1<<16){
					return "Error de rango";
				}
			}

			if(Clasificador.modoInherente(op)){
				return "No Compatible con modo INH";
			}
			if(Clasificador.modoDirecto(op)){
				return "No Compatible con modo DIR";
			}
			if(Clasificador.modoExtendido(op)){
				return "No Compatible con modo EXT";	
			}

			if(Clasificador.modoInmediato8b(op)){
				return "No Compatible con modo IMM8";
			}
			if(Clasificador.modoInmediato16b(op)){
				return "No Compatible con modo IMM16";
			}
			if(Clasificador.modoIndizado5b(op)||Clasificador.modo_Cremento(op)||Clasificador.modoAcumulador(op)){
				return "No Compatible con modo IDX";
			}
			if(Clasificador.modoIndizado9b(op)){
				return "No Compatible con modo IDX1";
			}
			if(Clasificador.modoIndizado16b(op)){
				return "No Compatible con modo IDX2";
			}
			if(Clasificador.modoIndirecto16b(op)||Clasificador.modoAcumuladorIndirecto(op)){
				return "[No Compatible con modo IDX]";
			}
			if(Clasificador.modoRelativo8b(op)){
				return "No Compatible con modo REL8";
			}
			if(Clasificador.modoRelativo9b(op)){
				return "No Compatible con modo REL9";
			}
			if(Clasificador.modoRelativo16b(op)){
				return "No Compatible con modo REL16";
			}


			
		}
		return "....";
	}

}
